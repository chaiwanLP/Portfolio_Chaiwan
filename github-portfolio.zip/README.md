# Nova — Internship Portfolio

เว็บ Portfolio สำหรับสมัครฝึกงาน (HTML/CSS/JS ไฟล์เดียว ไม่ต้อง build)

## วิธีขึ้น GitHub Pages
1. สร้าง repository ใหม่บน GitHub (ตั้งเป็น Public) เช่น `portfolio` หรือ `<username>.github.io`
2. อัปโหลดไฟล์ `index.html`, `.nojekyll` และ `README.md` ขึ้นไป
3. ไปที่ **Settings → Pages** เลือก Source เป็น **Deploy from a branch** แล้วเลือก branch `main` โฟลเดอร์ `/ (root)` กด Save
4. รอ 1–2 นาที เว็บจะอยู่ที่ `https://<username>.github.io/<repo>/`

## สิ่งที่ต้องแก้ใน index.html
ค้นหาข้อความในวงเล็บเหลี่ยม `[ ... ]` แล้วแก้เป็นข้อมูลจริง รวมถึงอีเมล เบอร์โทร และลิงก์ GitHub / LinkedIn / Resume
